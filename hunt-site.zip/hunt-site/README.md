# Сайт «The Hunt For Numbers» — прокрутка номеров с выводом в игру

Что умеет:
- вход через Roblox (официальный OAuth 2.0, пароль сайт не видит);
- прокрутка номеров **RUS / BY / KZ** — те же форматы, регионы и редкости, что в игре (проверено на одних и тех же номерах);
- цена прокрутки **500 ₽** с игрового баланса, автопрокрут до 50, «стоп на редкости», скорость анимации;
- «Мои номера»: **Вывести в игру** (приходит в инвентарь за ~5 сек, даже если игрок сейчас играет) или **Продать** за рубли;
- если номер при выводе оказался занят в игре другим игроком — рубли возвращаются.

Всё бесплатно: хостинг **Render** (free) + база **Neon** (free Postgres).

---

## 1. База данных (Neon) — 3 минуты
1. Зарегистрируйтесь на https://neon.tech (можно через GitHub/Google).
2. Create project → регион **Europe (Frankfurt)**.
3. Скопируйте **Connection string** (вида `postgresql://user:pass@ep-xxx.eu-central-1.aws.neon.tech/neondb?sslmode=require`). Это `DATABASE_URL`. Таблицы сайт создаст сам.

## 2. Код на GitHub
1. Создайте приватный репозиторий на https://github.com/new (например `hunt-site`).
2. Нажмите *uploading an existing file* и перетащите **содержимое** архива (`server.js`, `plates.js`, `package.json`, `render.yaml`, папку `public`). Commit.

## 3. Хостинг (Render)
1. https://render.com → вход через GitHub → **New → Blueprint** → выберите репозиторий. Render прочитает `render.yaml`.
2. Заполните переменные:
   - `DATABASE_URL` — строка из Neon;
   - `PUBLIC_URL` — адрес сайта, например `https://hunt-numbers.onrender.com` (его видно после создания; можно вписать позже);
   - `GAME_URL` — ссылка на игру, например `https://www.roblox.com/games/<ID плейса>`;
   - `ROBLOX_CLIENT_ID`, `ROBLOX_CLIENT_SECRET` — из шага 4 (можно вписать позже и нажать *Manual Deploy*).
   - `SESSION_SECRET` и `GAME_SECRET` Render придумает сам. **`GAME_SECRET` скопируйте** (Environment → глазик) — он нужен в игре.
3. Deploy. Проверка: `https://<ваш-сайт>/healthz` отвечает `ok`.

> Бесплатный Render «засыпает» через 15 минут без запросов и просыпается ~30–50 сек. Пока в игре есть хотя бы один сервер, игра будит его каждые 5 секунд, так что при живой игре сайт не спит.

## 4. Вход через Roblox (OAuth-приложение)
1. https://create.roblox.com/dashboard/credentials?activeTab=OAuthTab → **Create OAuth App**.
2. Название — например «The Hunt For Numbers — сайт». Скопируйте **Client ID** и **Client Secret** (секрет показывается один раз) → в Render.
3. **Permissions**: `openid` и `profile`. Больше ничего не нужно.
4. **Redirect URL**: `https://<ваш-сайт>/auth/callback` (ровно так, без / на конце).
5. Entry Link: `https://<ваш-сайт>/`, Privacy: `https://<ваш-сайт>/privacy.html`, Terms: `https://<ваш-сайт>/terms.html`.

⚠️ Новое приложение Roblox работает в **private mode — максимум 10 разных игроков**. Чтобы сайт открылся всем, нажмите **Edit and Publish → Review and Publish**: нужны описание и короткое демо-видео (вход → прокрутка → вывод в игру). Пока идёт проверка, вы и ещё 9 человек можете пользоваться сайтом.

## 5. Игра (уже сделано в Studio)
В плейсе The Hunt For Numbers уже добавлено:
- `ServerScriptService.WebsiteBridge` — связь с сайтом. **Откройте его и впишите в начале** `SITE_URL` (адрес сайта) и `GAME_SECRET` (из Render).
- `LicensePlateServer` принимает номера с сайта (`ServerStorage.ImportWebsitePlate`), `CurrencySystem` отмечает загрузку баланса.
- `StarterPlayerScripts.WebsiteNotifyClient` — уведомления «−500 ₽ за прокрутки на сайте», «Номер с сайта … уже в инвентаре».
- Включён **Allow HTTP Requests** (Game Settings → Security). Если выключится — включите.

Опубликуйте плейс (File → Publish to Roblox).

## Как это работает
- **Рубли живут в игре.** Игровые серверы каждые 5 сек присылают сайту баланс игроков. Сайт показывает `баланс − ещё не применённые прокрутки`.
- Прокрутка на сайте записывает «списание 500 ₽». Игра забирает новые списания и вычитает рубли (онлайн — сразу, оффлайн — при следующем входе). Номер последнего применённого списания хранится в DataStore `WebsiteBridge_v1`, поэтому дважды ничего не спишется.
- **Вывести в игру** → номер уходит в очередь → игра регистрирует его в общем реестре номеров и кладёт в инвентарь. Если номер уже занят — возврат рублей.
- Новичку надо **хотя бы раз зайти в игру** — до этого сайт не знает его баланс и прокрутка недоступна.

## Локальный запуск (для проверки)
```
npm install
DATABASE_URL=postgres://... GAME_SECRET=test PUBLIC_URL=http://localhost:3000 ROBLOX_CLIENT_ID=... ROBLOX_CLIENT_SECRET=... node server.js
```
(для localhost добавьте в OAuth-приложение Redirect URL `http://localhost:3000/auth/callback`)
